# Copyright 1996-2021 Cyberbotics Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Pedestrian class container."""
from controller import Supervisor

import optparse
import math


class Pedestrian (Supervisor):
    """Control a Pedestrian PROTO."""

    def __init__(self):
        """Constructor: initialize constants."""
        self.simtime=0
        self.joints_position_field = []
        self.joint_names = [
            "leftArmAngle", "leftLowerArmAngle", "leftHandAngle",
            "rightArmAngle", "rightLowerArmAngle", "rightHandAngle",
            "leftLegAngle", "leftLowerLegAngle", "leftFootAngle",
            "rightLegAngle", "rightLowerLegAngle", "rightFootAngle",
            "headAngle"
        ]
        self.BODY_PARTS_NUMBER = len(self.joint_names)
        Supervisor.__init__(self)

    def run(self):
        self.time_step = int(self.getBasicTimeStep())
        self.root_node_ref = self.getSelf()
        self.root_translation_field = self.root_node_ref.getField("translation")
        self.root_rotation_field = self.root_node_ref.getField("rotation")

        for i in range(0, self.BODY_PARTS_NUMBER):
            self.joints_position_field.append(self.root_node_ref.getField(self.joint_names[i]))

        #simulation loop (while true)
        while not self.step(self.time_step) == -1:
            time = self.getTime()
            self.simtime+=self.time_step/1000.0

            #use a sine wave to set current angle of a joint
            current_angle_leftshoulder = math.sin(self.simtime)-math.pi/2
            #wave one joint in a sine wave fashion.
            self.joints_position_field[0].setSFFloat(1*current_angle_leftshoulder)
            #wave a second joint w/ a different sine wave
            current_angle_leftelbow = -math.sin(self.simtime + math.pi/2)-math.pi/2
            self.joints_position_field[1].setSFFloat(1*current_angle_leftelbow)




controller = Pedestrian()
controller.run()
